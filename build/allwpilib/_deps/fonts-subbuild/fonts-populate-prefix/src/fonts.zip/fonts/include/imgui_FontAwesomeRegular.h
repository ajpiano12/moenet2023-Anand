#pragma once
#include "imgui.h"
namespace ImGui {
ImFont* AddFontFontAwesomeRegular(ImGuiIO& io, float size_pixels, const ImFontConfig* font_cfg = nullptr, const ImWchar* glyph_ranges = nullptr);
}
